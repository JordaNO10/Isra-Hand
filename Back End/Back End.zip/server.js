const express = require("express");
const bodyParser = require("body-parser");
const helmet = require("helmet");
const morgan = require("morgan");
const path = require("path");
const fs = require("fs");
const sessionMiddleware = require("./config/session");
const cors = require("cors");

const signin = require("./database/signin");
const signUp = require("./database/signup");
const logoutRoute = require("./database/logout");
const usersRouter = require("./database/users");
const donationAll = require("./database/donations");
const donationAdd = require("./database/donationadd");
const categories = require("./database/categories");
const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS for all routes
const corsOptions = {
  origin: "http://localhost:3000", // Frontend URL
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], // Allowed HTTP methods
  allowedHeaders: ["Content-Type", "Authorization"], // Allowed headers
};

app.use(cors(corsOptions)); // Apply CORS middleware to all routes

// Other middlewares and routes
app.use(helmet());
app.use(morgan("combined"));
app.use(bodyParser.json());

// Ensure the uploads directory exists
const uploadDirectory = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDirectory)) {
  fs.mkdirSync(uploadDirectory, { recursive: true });
}

// Middleware for session handling
sessionMiddleware(app);

// Serve static files from the uploads directory
app.use(
  "/uploads",
  (req, res, next) => {
    res.setHeader("Cross-Origin-Resource-Policy", "same-site");
    next();
  },
  express.static(path.join(__dirname, "uploads"))
);

// Routes
app.use("/signin", signin);
app.use("/signUp", signUp);
app.use("/logout", logoutRoute);
app.use("/users", usersRouter);
app.use("/donations", donationAll);
app.use("/donationadd", donationAdd);
app.use("/categories", categories);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Something went wrong!" });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
